from django.apps import AppConfig


class FacultyConfig(AppConfig):
    name = 'faculty'
